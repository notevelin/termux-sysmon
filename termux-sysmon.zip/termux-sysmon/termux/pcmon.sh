#!/data/data/com.termux/files/usr/bin/bash

HOST=${1:-127.0.0.1}
PORT=${2:-5050}

cleanup() {
  exec 3>&- 2>/dev/null
  printf '\e[0m\n'
  exit 0
}
trap cleanup INT TERM

if ! exec 3<>"/dev/tcp/$HOST/$PORT" 2>/dev/null; then
  echo "Не удалось подключиться к $HOST:$PORT"
  echo "1. На ПК запущен pc-server.ps1?"
  echo "2. На ПК выполнено: adb reverse tcp:$PORT tcp:$PORT"
  echo "3. Или запусти через Wi-Fi: ./pcmon.sh <IP_ПК>"
  exit 1
fi

printf '\e[H\e[2JПодключено к %s:%s. Ctrl+C — выход.\n' "$HOST" "$PORT"

while IFS= read -r -u 3 line; do
  printf '%s\n' "$line"
done

printf '\e[0m\nСоединение закрыто.\n'
