#!/data/data/com.termux/files/usr/bin/bash

RST=$'\e[0m'
BOLD=$'\e[1m'
DIM=$'\e[2m'
GRN=$'\e[32m'
YEL=$'\e[33m'
RED=$'\e[31m'
CYN=$'\e[36m'

REFRESH=3

hr() {
  local b=$1
  if (( b >= 1073741824 )); then
    printf '%d.%dГБ' $(( b / 1073741824 )) $(( ( b % 1073741824 ) * 10 / 1073741824 ))
  elif (( b >= 1048576 )); then
    printf '%dМБ' $(( ( b + 524288 ) / 1048576 ))
  else
    printf '%dКБ' $(( ( b + 1024 ) / 1024 ))
  fi
}

pct() {
  local n=$1 d=$2
  (( d <= 0 )) && { printf 0; return; }
  printf '%d' $(( ( n * 100 + d / 2 ) / d ))
}

bar() {
  local p=$1 w=${2:-20} i col filled
  (( p > 100 )) && p=100
  (( p < 0 )) && p=0
  if (( p >= 80 )); then col=$RED; elif (( p >= 50 )); then col=$YEL; else col=$GRN; fi
  filled=$(( p * w / 100 ))
  printf '%s[' "$col"
  for (( i = 0; i < filled; i++ )); do printf '#'; done
  for (( i = filled; i < w; i++ )); do printf '.'; done
  printf ']%s' "$RST"
}

fmt_temp() {
  local t=$1
  if (( t >= 1000 )); then
    printf '%d.%d°C' $(( t / 1000 )) $(( ( t % 1000 ) / 100 ))
  else
    printf '%d.%d°C' $(( t / 10 )) $(( t % 10 ))
  fi
}

ru_status() {
  case $1 in
    Charging) printf 'Зарядка' ;;
    Discharging) printf 'Разрядка' ;;
    Full) printf 'Полный' ;;
    'Not charging') printf 'Не заряжается' ;;
    *) printf '%s' "${1:-н/д}" ;;
  esac
}

ru_health() {
  case $1 in
    Good) printf 'Хорошо' ;;
    Overheat) printf 'Перегрев' ;;
    Dead) printf 'Не работает' ;;
    Cold) printf 'Холодно' ;;
    *) printf '%s' "${1:-н/д}" ;;
  esac
}

cpu_times() {
  local line rest v total=0
  read -r line < /proc/stat || return 1
  case $line in
    cpu\ *) ;;
    *) return 1 ;;
  esac
  rest=${line#cpu }
  for v in $rest; do
    total=$(( total + v ))
  done
  set -- $rest
  C_T=$total
  C_I=$(( ${4:-0} + ${5:-0} ))
}

read_file() {
  local v
  read -r v < "$1" 2>/dev/null || v=""
  printf '%s' "$v"
}

collect_mem() {
  declare -gA M=()
  local k v
  while read -r k v _; do
    k=${k%:}
    [[ $k =~ ^[A-Za-z]+$ ]] && M[$k]=$(( v * 1024 ))
  done < /proc/meminfo
  MEM_T=${M[MemTotal]:-0}
  MEM_A=${M[MemAvailable]:-0}
  if (( MEM_A == 0 )); then
    MEM_A=$(( ${M[MemFree]:-0} + ${M[Buffers]:-0} + ${M[Cached]:-0} ))
  fi
  MEM_U=$(( MEM_T - MEM_A ))
  SW_T=${M[SwapTotal]:-0}
  SW_U=$(( SW_T - ${M[SwapFree]:-0} ))
}

collect_battery() {
  BAT_CAP=$(read_file /sys/class/power_supply/battery/capacity)
  BAT_ST=$(read_file /sys/class/power_supply/battery/status)
  BAT_HLTH=$(read_file /sys/class/power_supply/battery/health)
  BAT_T=$(read_file /sys/class/power_supply/battery/temp)
  BAT_V=$(read_file /sys/class/power_supply/battery/voltage_now)
}

collect_thermal() {
  local z t typ count=0 matched="" hottest="" max_t=-1 max_typ=""
  for z in /sys/class/thermal/thermal_zone*; do
    [ -r "$z/temp" ] || continue
    t=$(read_file "$z/temp")
    [[ $t =~ ^[0-9]+$ ]] || continue
    typ=$(read_file "$z/type")
    [ -n "$typ" ] || typ="zone"
    if (( t > max_t )); then max_t=$t; max_typ=$typ; fi
    case $typ in
      *cpu*|*CPU*|*cluster*|*gpu*|*GPU*|*xo*|*skin*|*pa_*|*modem*)
        if (( count < 4 )); then
          matched+="${matched:+ | }${typ}: $(fmt_temp "$t")"
          count=$(( count + 1 ))
        fi
        ;;
    esac
  done
  if [ -n "$matched" ]; then
    THERM=$matched
  elif (( max_t >= 0 )); then
    THERM="${max_typ}: $(fmt_temp "$max_t")"
  else
    THERM="н/д"
  fi
}

collect_cpu_extra() {
  local c f best=0
  NCPU=0
  for c in /sys/devices/system/cpu/cpu[0-9]*; do
    [ -d "$c" ] || continue
    NCPU=$(( NCPU + 1 ))
    if [ -r "$c/cpufreq/scaling_cur_freq" ]; then
      f=$(read_file "$c/cpufreq/scaling_cur_freq")
      [[ $f =~ ^[0-9]+$ ]] || f=0
      (( f > best )) && best=$f
    fi
  done
  if (( best > 0 )); then
    FREQ=$(( best / 1000 ))
  else
    FREQ=0
    local _k1 _k2 _k3 mhz maxm=0
    while read -r _k1 _k2 _k3 mhz; do
      mhz=${mhz%%.*}
      [[ $mhz =~ ^[0-9]+$ ]] || continue
      (( mhz > maxm )) && maxm=$mhz
    done < /proc/cpuinfo
    FREQ=$maxm
  fi
}

collect_procs() {
  local p rss nm line list="" n=0
  for p in /proc/[0-9]*; do
    [ -r "$p/statm" ] || continue
    read -r _ rss _ < "$p/statm" 2>/dev/null || continue
    [[ $rss =~ ^[0-9]+$ ]] || continue
    (( rss > 0 )) || continue
    n=$(( n + 1 ))
    nm=""
    if [ -r "$p/status" ]; then
      while IFS= read -r line; do
        case $line in
          Name:*) nm=${line#Name:}; nm=${nm# }; break ;;
        esac
      done < "$p/status"
    fi
    [ -n "$nm" ] || nm="?"
    list+="$(( rss * 4 ))"$'\t'"$nm"$'\n'
  done
  PCOUNT=$n
  TOP=$(printf '%s' "$list" | sort -rn | head -n 8)
}

collect_disk() {
  DISK_OK=0
  local target="" line fs sz us av pm
  [ -d /data ] && target=/data
  [ -n "$target" ] || target=/
  line=$(df -k "$target" 2>/dev/null | tail -n 1)
  [ -n "$line" ] || return
  read -r fs sz us av pm _ <<< "$line"
  [[ $sz =~ ^[0-9]+$ ]] || return
  DISK_MNT=$target
  DISK_T=$(( sz * 1024 ))
  DISK_U=$(( us * 1024 ))
  DISK_P=$(pct "$DISK_U" "$DISK_T")
  DISK_OK=1
}

draw() {
  printf '\e[H\e[2J'

  local p

  printf '%s%s══ СИСТЕМНЫЙ МОНИТОР ══%s\n' "$BOLD" "$CYN" "$RST"
  printf '%sУстройство:%s %s | Android %s | Ядро %s\n' "$DIM" "$RST" "$MODEL" "$ANDROID" "$KVER"
  printf '%sАптайм:%s %s | %sЗагрузка:%s %s | %sПроцессов:%s %d\n\n' \
    "$DIM" "$RST" "$UPTIME" "$DIM" "$RST" "$LOAD" "$DIM" "$RST" "$PCOUNT"

  if [ -n "$BAT_CAP" ]; then
    p=$(pct "$BAT_CAP" 100)
    printf '%sБАТАРЕЯ%s  %3s%% ' "$BOLD" "$RST" "$BAT_CAP"
    bar "$p" 20
    printf '  %s' "$(ru_status "$BAT_ST")"
    [ -n "$BAT_T" ] && printf ' | %s' "$(fmt_temp "$BAT_T")"
    if [[ $BAT_V =~ ^[0-9]+$ ]] && (( BAT_V > 0 )); then
      printf ' | %d.%02dВ' $(( BAT_V / 1000000 )) $(( ( BAT_V % 1000000 ) / 10000 ))
    fi
    [ -n "$BAT_HLTH" ] && printf ' | Здоровье: %s' "$(ru_health "$BAT_HLTH")"
    printf '\n'
  else
    printf '%sБАТАРЕЯ%s  нет данных\n' "$BOLD" "$RST"
  fi

  p=$(pct "$CPU_P" 100)
  printf '%sЦП%s      %3d%% ' "$BOLD" "$RST" "$CPU_P"
  bar "$p" 20
  if (( FREQ > 0 )); then printf ' | %dМГц' "$FREQ"; fi
  printf ' | %d яд. | %s\n' "$NCPU" "$THERM"

  p=$(pct "$MEM_U" "$MEM_T")
  printf '%sОЗУ%s     %3d%% ' "$BOLD" "$RST" "$p"
  bar "$p" 20
  printf '  %s / %s' "$(hr "$MEM_U")" "$(hr "$MEM_T")"
  printf ' | свободно %s' "$(hr "$MEM_A")"
  if (( SW_T > 0 )); then
    printf ' | подкачка %s/%s' "$(hr "$SW_U")" "$(hr "$SW_T")"
  fi
  printf '\n'

  if (( DISK_OK )); then
    printf '%sДИСК%s    %3d%% ' "$BOLD" "$RST" "$DISK_P"
    bar "$DISK_P" 20
    printf '  %s / %s на %s\n' "$(hr "$DISK_U")" "$(hr "$DISK_T")" "$DISK_MNT"
  fi

  printf '\n%sТОП ПО ПАМЯТИ:%s\n' "$BOLD" "$RST"
  local i=0 kb nm
  while IFS=$'\t' read -r kb nm; do
    [ -n "$kb" ] || continue
    i=$(( i + 1 ))
    printf '  %d. %8s  %s\n' "$i" "$(hr $(( kb * 1024 )))" "$nm"
  done <<< "$TOP"

  printf '\n%sCtrl+C — выход | обновление каждые %dс%s\n' "$DIM" "$REFRESH" "$RST"
}

MODEL=$(getprop ro.product.model 2>/dev/null)
[ -n "$MODEL" ] || MODEL=$(getprop ro.product.device 2>/dev/null)
[ -n "$MODEL" ] || MODEL="Android"
ANDROID=$(getprop ro.build.version.release 2>/dev/null)
[ -n "$ANDROID" ] || ANDROID="?"
KVER=$(uname -r 2>/dev/null)
[ -n "$KVER" ] || KVER="?"

trap 'printf "%s\n" "$RST"; exit 0' INT TERM

while true; do
  cpu_times
  t0=$C_T
  i0=$C_I

  collect_mem
  collect_battery
  collect_thermal
  collect_cpu_extra
  collect_procs
  collect_disk

  read -r up _ < /proc/uptime
  up=${up%%.*}
  d=$(( up / 86400 ))
  h=$(( up % 86400 / 3600 ))
  m=$(( up % 3600 / 60 ))
  UPTIME=""
  (( d > 0 )) && UPTIME+="${d}д "
  UPTIME+=$(printf '%02d:%02d' "$h" "$m")

  read -r l1 l2 l3 < /proc/loadavg 2>/dev/null
  LOAD="${l1:-0} ${l2:-0} ${l3:-0}"

  sleep 1

  cpu_times
  dt=$(( C_T - t0 ))
  di=$(( C_I - i0 ))
  if (( dt > 0 )); then
    CPU_P=$(( ( dt - di ) * 100 / dt ))
    (( CPU_P < 0 )) && CPU_P=0
    (( CPU_P > 100 )) && CPU_P=100
  else
    CPU_P=0
  fi

  draw
  sleep "$REFRESH"
done
