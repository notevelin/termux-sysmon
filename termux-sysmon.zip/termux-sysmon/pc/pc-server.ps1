﻿param(
    [int]$Port = 5050,
    [int]$Interval = 3
)

$ErrorActionPreference = 'SilentlyContinue'
$esc = [char]27
$nl = "`n"

function Size([int64]$b) {
    if ($b -ge 1073741824) { return ('{0:0.#} ГБ' -f ($b / 1073741824)) }
    if ($b -ge 1048576) { return ('{0} МБ' -f [int](($b + 524288) / 1048576)) }
    return ('{0} КБ' -f [int](($b + 1024) / 1024))
}

function Bar([int]$p, [int]$w = 20) {
    if ($p -lt 0) { $p = 0 }
    if ($p -gt 100) { $p = 100 }
    $fill = [int](($p * $w) / 100)
    $color = 32
    if ($p -ge 80) { $color = 31 }
    elseif ($p -ge 50) { $color = 33 }
    $s = ('#' * $fill).PadRight($w, [char]'.')
    return "$esc[${color}m[$s]$esc[0m"
}

function Get-Frame {
    $out = New-Object System.Collections.Generic.List[string]

    $os = Get-CimInstance Win32_OperatingSystem
    if (-not $os) {
        $out.Add("$esc[H$esc[2J$esc[31mОшибка: нет данных об ОС$esc[0m")
        return ($out -join $nl + $nl)
    }

    $cpus = @(Get-CimInstance Win32_Processor)
    $cpu = $cpus[0]

    $load = 0
    if ($cpus.Count -gt 0) {
        $m = $cpus | Measure-Object -Property LoadPercentage -Average
        if ($null -ne $m.Average) { $load = [int][Math]::Round($m.Average) }
    }

    $totalRam = [int64]($os.TotalVisibleMemorySize) * 1024
    $freeRam = [int64]($os.FreePhysicalMemory) * 1024
    $usedRam = $totalRam - $freeRam
    $ramPct = 0
    if ($totalRam -gt 0) { $ramPct = [int][Math]::Round($usedRam * 100.0 / $totalRam) }

    $up = (Get-Date) - $os.LastBootUpTime
    $uptime = ''
    if ($up.Days -gt 0) { $uptime += "$($up.Days)д " }
    $uptime += ('{0:00}:{1:00}' -f $up.Hours, $up.Minutes)

    $cpuName = ''
    $cores = 0
    $logical = 0
    if ($cpu) {
        $cpuName = ([string]$cpu.Name).Trim()
        $cores = [int](($cpus | Measure-Object -Property NumberOfCores -Sum).Sum)
        $logical = [int](($cpus | Measure-Object -Property NumberOfLogicalProcessors -Sum).Sum)
    }

    $out.Add("$esc[1m$esc[36m══ СИСТЕМНЫЙ МОНИТОР — ПК ══$esc[0m")
    $out.Add("$esc[2mПК:$esc[0m $env:COMPUTERNAME | $cpuName")
    $out.Add("$esc[2mОС:$esc[0m $($os.Caption) | $esc[2mЯдра:$esc[0m $cores/$logical | $esc[2mАптайм:$esc[0m $uptime")
    $out.Add('')

    $bat = Get-CimInstance Win32_Battery
    if ($bat) {
        $bp = 0
        if ($null -ne $bat.EstimatedChargeRemaining) { $bp = [int]$bat.EstimatedChargeRemaining }
        $st = [int]$bat.BatteryStatus
        $bs = 'Разрядка'
        if ($st -eq 3) { $bs = 'Полный' }
        elseif ($st -ge 6 -and $st -le 9) { $bs = 'Зарядка' }
        $out.Add("$esc[1mБАТАРЕЯ$esc[0m  $bp% $(Bar $bp)  $bs")
    } else {
        $out.Add("$esc[1mБАТАРЕЯ$esc[0m  нет батареи")
    }

    $out.Add("$esc[1mЦП$esc[0m      $load% $(Bar $load)  $cores яд. / $logical пот.")
    $out.Add("$esc[1mОЗУ$esc[0m     $ramPct% $(Bar $ramPct)  $(Size $usedRam) / $(Size $totalRam) | свободно $(Size $freeRam)")

    $disks = @(Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3')
    foreach ($d in $disks) {
        $dt = [int64]$d.Size
        $df = [int64]$d.FreeSpace
        $du = $dt - $df
        $dp = 0
        if ($dt -gt 0) { $dp = [int][Math]::Round($du * 100.0 / $dt) }
        $out.Add("$esc[1mДИСК$esc[0m    $($d.DeviceID) $dp% $(Bar $dp)  $(Size $du) / $(Size $dt)")
    }

    $out.Add('')
    $out.Add("$esc[1mТОП ПО ПАМЯТИ:$esc[0m")
    $i = 0
    foreach ($p in (Get-Process | Sort-Object -Property WS -Descending | Select-Object -First 8)) {
        $i++
        $ws = [int64]0
        if ($null -ne $p.WS) { $ws = [int64]$p.WS }
        $out.Add(('  {0}. {1,9}  {2}' -f $i, (Size $ws), $p.ProcessName))
    }

    $out.Add('')
    $out.Add("$esc[2mОбновление: $Interval с | Ctrl+C — остановка$esc[0m")

    return ("$esc[H$esc[2J" + ($out -join $nl) + $nl)
}

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Any, $Port)
$listener.Start()

Write-Host "Сервер запущен, порт $Port" -ForegroundColor Green
$ips = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.IPAddress -notlike '169.254*' } | Select-Object -ExpandProperty IPAddress
if ($ips) { Write-Host "IP для Wi-Fi: $($ips -join ', ')" }
Write-Host "Для USB: adb reverse tcp:$Port tcp:$Port"
Write-Host "Ctrl+C — остановка"

while ($true) {
    $client = $listener.AcceptTcpClient()
    $stream = $client.GetStream()
    Write-Host "Клиент подключён: $($client.Client.RemoteEndPoint)"
    try {
        while ($true) {
            if ($client.Client.Poll(0, [System.Net.Sockets.SelectMode]::SelectRead) -and $client.Client.Available -eq 0) { break }
            $frame = Get-Frame
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($frame)
            $stream.Write($bytes, 0, $bytes.Length)
            $stream.Flush()
            Start-Sleep -Seconds $Interval
        }
    } catch {
        Write-Host "Соединение прервано"
    }
    $client.Close()
    Write-Host "Клиент отключился"
}
